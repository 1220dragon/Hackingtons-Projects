@echo off
color 0a

:: 1. Define the filename first!
set filename=warning_%random%.txt

echo Initializing...
timeout /t 1 /nobreak >nul

echo Fetching network data...
:: This displays the IP info to look scary
ipconfig
timeout /t 1 /nobreak >nul

echo Finishing transfer...
timeout /t 1 /nobreak >nul

:: 2. Create the actual file content
echo YOUR IP ADDRESS HAS BEEN STOLEN (JUST KIDDING!) > %filename%

:myloop
:: 3. Open a NEW instance each time
start "" notepad.exe %filename%

timeout /t 1 /nobreak >nul
goto myloop